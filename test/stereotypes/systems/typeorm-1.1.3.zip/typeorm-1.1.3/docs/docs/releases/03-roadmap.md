# Roadmap

You can track upcoming releases and their progress via GitHub milestones:

- [**1.0**](https://github.com/typeorm/typeorm/milestone/11) — the next major release, including removal of all deprecated APIs, modernized defaults, and breaking changes outlined in the [upgrading guide](./1.0/02-upgrading-from-0.3.md).

For a full list of milestones, see the [milestones page](https://github.com/typeorm/typeorm/milestones).

## Join Us in Supporting TypeORM

If your company is interested in starting or expanding its sponsorship with TypeORM, we encourage you to reach out to us directly [via e-mail](mailto:maintainers@typeorm.io).

Thank you for your support, and we're excited to embark on this journey with the TypeORM community!

## Join the Conversation

Have questions or want to get involved? Join our [Discord community](https://discord.gg/cC9hkmUgNa) or check out our [GitHub repository](https://github.com/typeorm/typeorm).
