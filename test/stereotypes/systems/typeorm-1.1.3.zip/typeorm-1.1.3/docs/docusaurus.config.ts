import type * as Preset from "@docusaurus/preset-classic"
import type { Config } from "@docusaurus/types"
import { PluginOptions as LLMsTXTPluginOptions } from "@signalwire/docusaurus-plugin-llms-txt"
import { themes as prismThemes } from "prism-react-renderer"
import { redirects } from "./redirects"

// This runs in Node.js - Don't use client-side code here (browser APIs, JSX...)

const config: Config = {
    title: "TypeORM",
    tagline: "Code with Confidence. Query with Power.",
    favicon: "img/favicon.ico",

    // Set the production url of your site here
    url: "https://typeorm.io",
    // Set the /<baseUrl>/ pathname under which your site is served
    // For GitHub pages deployment, it is often '/<projectName>/'
    baseUrl: "/",

    // GitHub pages deployment config.
    // If you aren't using GitHub pages, you don't need these.
    organizationName: "typeorm", // Usually your GitHub org/user name.
    projectName: "typeorm", // Usually your repo name.

    onBrokenLinks: "throw",

    // Even if you don't use internationalization, you can use this field to set
    // useful metadata like html lang. For example, if your site is Chinese, you
    // may want to replace "en" with "zh-Hans".
    i18n: {
        defaultLocale: "en",
        locales: ["en"],
    },

    // Plausible cookieless analytics for tracking site usage while respecting privacy
    scripts:
        process.env.NODE_ENV === "production"
            ? [
                  {
                      src: "https://plausible.io/js/script.hash.js",
                      defer: true,
                      "data-domain": "typeorm.io",
                  },
                  {
                      src: "https://widget.kapa.ai/kapa-widget.bundle.js",
                      "data-website-id": "a9979852-2282-4862-87b3-b3631fb63d46",
                      "data-project-name": "TypeORM",
                      "data-project-color": "#d94400",
                      "data-project-logo":
                          "https://typeorm.io/img/typeorm-icon-colored.png",
                      "data-mcp-enabled": "true",
                      "data-mcp-server-url": "https://typeorm.mcp.kapa.ai",
                      async: true,
                  },
              ]
            : [],

    stylesheets: [
        "https://fonts.googleapis.com/css2?family=Geist:wght@400;500;600;700&family=Geist+Mono:wght@400;500&family=Sofia+Sans:wght@700&display=swap",
    ],

    presets: [
        [
            "@docusaurus/preset-classic",
            {
                docs: {
                    sidebarPath: "./sidebars.ts",
                    // Please change this to your repo.
                    // Remove this to remove the "edit this page" links.
                    editUrl:
                        "https://github.com/typeorm/typeorm/tree/master/docs/",
                },
                blog: {
                    showReadingTime: true,
                    blogTitle: "TypeORM Blog",
                    blogDescription:
                        "News, release updates, and insights from the TypeORM team.",
                    blogSidebarTitle: "Recent Posts",
                    blogSidebarCount: 10,
                    postsPerPage: 10,
                    feedOptions: {
                        type: ["rss", "atom"],
                        title: "TypeORM Blog",
                        description:
                            "News, release updates, and insights from the TypeORM team.",
                        copyright: `Copyright © ${new Date().getFullYear()} TypeORM`,
                    },
                    editUrl:
                        "https://github.com/typeorm/typeorm/tree/master/docs/",
                },
                sitemap: {
                    lastmod: "datetime",
                    changefreq: null,
                },
                theme: {
                    customCss: "./src/css/custom.css",
                },
            } satisfies Preset.Options,
        ],
    ],
    themeConfig: {
        // Replace with your project's social card
        image: "img/typeorm-social-card.jpg",
        announcementBar: {
            id: "v1_release",
            content:
                'TypeORM 1.0 is here! Check the <a href="/docs/releases/1.0/release-notes">release notes</a> and <a href="/docs/releases/1.0/upgrading-from-0.3">upgrading guide</a>.',
            backgroundColor: "#d94400",
            textColor: "#ffffff",
            isCloseable: true,
        },
        colorMode: {
            defaultMode: "light",
            disableSwitch: false,
            respectPrefersColorScheme: true,
        },
        navbar: {
            title: "TypeORM",
            logo: {
                alt: "TypeORM Logo",
                src: "img/typeorm-icon-colored.png",
                srcDark: "img/typeorm-icon-white.png",
                width: 46,
                height: 64,
            },
            items: [
                {
                    type: "docSidebar",
                    sidebarId: "tutorialSidebar",
                    position: "left",
                    label: "Docs",
                },
                {
                    to: "/maintainers",
                    label: "Maintainers",
                    position: "left",
                },
                {
                    to: "/blog",
                    label: "Blog",
                    position: "left",
                },
                {
                    type: "dropdown",
                    label: "Version 1.x",
                    position: "right",
                    className: "navbar__version-trigger",
                    items: [
                        {
                            html: '<span class="navbar__version-section-label">Latest</span>',
                            to: "#",
                            className: "navbar__version-section",
                        },
                        {
                            label: "Version 1.x",
                            href: "https://typeorm.io",
                            className:
                                "navbar__version-item navbar__version-item--active",
                        },
                        {
                            html: '<span class="navbar__version-section-label">Legacy</span>',
                            to: "#",
                            className: "navbar__version-section",
                        },
                        {
                            label: "Version 0.3.x",
                            href: "https://v0.typeorm.io",
                            className: "navbar__version-item",
                        },
                    ],
                },
                {
                    href: "https://github.com/typeorm/typeorm",
                    label: "GitHub",
                    position: "right",
                },
            ],
        },
        footer: {
            style: "dark",
            links: [
                {
                    title: "Docs",
                    items: [
                        {
                            label: "Getting started",
                            to: "/docs/getting-started",
                        },
                    ],
                },
                {
                    title: "Community",
                    items: [
                        {
                            label: "Discord",
                            href: "https://discord.gg/cC9hkmUgNa",
                        },
                        {
                            label: "Stack Overflow",
                            href: "https://stackoverflow.com/questions/tagged/typeorm",
                        },
                        {
                            label: "Maintainers",
                            to: "/maintainers",
                        },
                    ],
                },
                {
                    title: "More",
                    items: [
                        {
                            label: "Blog",
                            to: "/blog",
                        },
                        {
                            label: "GitHub",
                            href: "https://github.com/typeorm/typeorm",
                        },
                        {
                            label: "LinkedIn",
                            href: "https://www.linkedin.com/company/typeorm",
                        },
                    ],
                },
            ],
            copyright: `Copyright © ${new Date().getFullYear()} TypeORM. Built with Docusaurus.`,
        },
        prism: {
            theme: prismThemes.github,
            darkTheme: prismThemes.dracula,
            additionalLanguages: [
                "typescript",
                "javascript",
                "bash",
                "json",
                "sql",
            ],
        },
    } satisfies Preset.ThemeConfig,
    plugins: [
        [
            "@docusaurus/plugin-client-redirects",
            {
                redirects,
            },
        ],
        [
            "@signalwire/docusaurus-plugin-llms-txt",
            {
                content: {
                    // https://www.npmjs.com/package/@signalwire/docusaurus-plugin-llms-txt#content-selectors
                    contentSelectors: [
                        ".theme-doc-markdown", // Docusaurus main content area
                        "main .container .col", // Bootstrap-style layout
                        "main .theme-doc-wrapper", // Docusaurus wrapper
                        "article", // Semantic article element
                        "main .container", // Broader container
                        "main", // Fallback to main element
                        ".code-example",
                    ],
                    enableLlmsFullTxt: true,
                    includeGeneratedIndex: false,
                    includePages: true,
                    includeVersionedDocs: false,
                    relativePaths: false,
                },
                depth: 3,
                onRouteError: "throw",
                siteTitle: "TypeORM",
                siteDescription:
                    "TypeORM is an ORM that can run in NodeJS, Browser, Cordova, Ionic, React Native, NativeScript, Expo, and Electron platforms and can be used with TypeScript and JavaScript.",
            } satisfies LLMsTXTPluginOptions,
        ],
        "docusaurus-lunr-search",
    ],
}

export default config
