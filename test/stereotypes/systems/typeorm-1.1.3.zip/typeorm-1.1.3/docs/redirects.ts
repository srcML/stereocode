export const redirects = [
    { from: "/docs", to: "/docs/getting-started" },
    { from: "/entities", to: "/docs/entity/entities" },
    { from: "/embedded-entities", to: "/docs/entity/embedded-entities" },
    { from: "/entity-inheritance", to: "/docs/entity/entity-inheritance" },
    { from: "/tree-entities", to: "/docs/entity/tree-entities" },
    { from: "/view-entities", to: "/docs/entity/view-entities" },
    {
        from: "/separating-entity-definition",
        to: "/docs/entity/separating-entity-definition",
    },

    { from: "/relations", to: "/docs/relations/relations" },
    {
        from: "/one-to-one-relations",
        to: "/docs/relations/one-to-one-relations",
    },
    {
        from: "/many-to-one-one-to-many-relations",
        to: "/docs/relations/many-to-one-one-to-many-relations",
    },
    {
        from: "/many-to-many-relations",
        to: "/docs/relations/many-to-many-relations",
    },
    {
        from: "/eager-and-lazy-relations",
        to: "/docs/relations/eager-and-lazy-relations",
    },
    { from: "/relations-faq", to: "/docs/relations/relations-faq" },

    {
        from: "/working-with-entity-manager",
        to: "/docs/working-with-entity-manager/working-with-entity-manager",
    },
    {
        from: "/working-with-repository",
        to: "/docs/working-with-entity-manager/working-with-repository",
    },
    {
        from: "/find-options",
        to: "/docs/working-with-entity-manager/find-options",
    },
    {
        from: "/custom-repository",
        to: "/docs/working-with-entity-manager/custom-repository",
    },
    {
        from: "/entity-manager-api",
        to: "/docs/working-with-entity-manager/entity-manager-api",
    },
    {
        from: "/repository-api",
        to: "/docs/working-with-entity-manager/repository-api",
    },

    {
        from: "/select-query-builder",
        to: "/docs/query-builder/select-query-builder",
    },
    {
        from: "/insert-query-builder",
        to: "/docs/query-builder/insert-query-builder",
    },
    {
        from: "/update-query-builder",
        to: "/docs/query-builder/update-query-builder",
    },
    {
        from: "/delete-query-builder",
        to: "/docs/query-builder/delete-query-builder",
    },
    {
        from: "/relational-query-builder",
        to: "/docs/query-builder/relational-query-builder",
    },
    { from: "/caching", to: "/docs/query-builder/caching" },

    {
        from: "/active-record-data-mapper",
        to: "/docs/guides/active-record-data-mapper",
    },
    { from: "/mongodb", to: "/docs/drivers/mongodb" },
    { from: "/docs/guides/mongodb", to: "/docs/drivers/mongodb" },
    { from: "/validation", to: "/docs/guides/validation" },
    { from: "/example-with-express", to: "/docs/guides/example-with-express" },
    {
        from: "/usage-with-javascript",
        to: "/docs/guides/usage-with-javascript",
    },
    { from: "/sequelize-migration", to: "/docs/guides/sequelize-migration" },

    { from: "/data-source", to: "/docs/data-source/data-source" },
    {
        from: "/data-source-options",
        to: "/docs/data-source/data-source-options",
    },
    {
        from: "/multiple-data-sources",
        to: "/docs/data-source/multiple-data-sources",
    },
    { from: "/data-source-api", to: "/docs/data-source/data-source-api" },

    { from: "/migrations", to: "/docs/migrations/why" },
    { from: "/transactions", to: "/docs/transactions" },
    { from: "/indices", to: "/docs/indexes" },
    {
        from: "/listeners-and-subscribers",
        to: "/docs/listeners-and-subscribers",
    },
    { from: "/logging", to: "/docs/logging" },
    { from: "/using-cli", to: "/docs/using-cli" },
    {
        from: "/performance-optimizing",
        to: "/docs/performance-optimization/introduction",
    },
    {
        from: "/docs/advanced-topics/transactions",
        to: "/docs/transactions",
    },
    { from: "/docs/indices", to: "/docs/indexes" },
    { from: "/docs/advanced-topics/indices", to: "/docs/indexes" },
    {
        from: "/docs/performance-optimization/using-indices",
        to: "/docs/performance-optimization/using-indexes",
    },
    {
        from: "/docs/advanced-topics/listeners-and-subscribers",
        to: "/docs/listeners-and-subscribers",
    },
    { from: "/docs/advanced-topics/logging", to: "/docs/logging" },
    {
        from: "/docs/advanced-topics/using-cli",
        to: "/docs/using-cli",
    },
    {
        from: "/docs/advanced-topics/performance-optimizing",
        to: "/docs/performance-optimization/introduction",
    },

    { from: "/faq", to: "/docs/help/faq" },
    { from: "/supported-platforms", to: "/docs/help/supported-platforms" },
    { from: "/decorator-reference", to: "/docs/help/decorator-reference" },
    { from: "/support", to: "/docs/help/support" },

    { from: "/getting-started", to: "/docs/getting-started" },
    { from: "/future-of-typeorm", to: "/blog/future-of-typeorm" },
    { from: "/docs/future-of-typeorm", to: "/blog/future-of-typeorm" },
    { from: "/query-runner", to: "/docs/query-runner" },
    { from: "/docs/advanced-topics/migrations", to: "/docs/migrations/why" },
    { from: "/docs/gsoc/2026", to: "/docs/getting-started" },
]
