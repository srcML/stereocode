import { getMetadataArgsStorage } from "../../globals"
import type { ColumnMetadataArgs } from "../../metadata-args/ColumnMetadataArgs"
import type { ColumnOptions } from "../options/ColumnOptions"

/**
 * This column will store an update date of the updated object.
 * This date is being updated each time you persist the object.
 *
 * @param options
 */
export function UpdateDateColumn(options?: ColumnOptions): PropertyDecorator {
    return function (object: Object, propertyName: string) {
        getMetadataArgsStorage().columns.push({
            target: object.constructor,
            propertyName: propertyName,
            mode: "updateDate",
            options: options ?? {},
        } as ColumnMetadataArgs)
    }
}
