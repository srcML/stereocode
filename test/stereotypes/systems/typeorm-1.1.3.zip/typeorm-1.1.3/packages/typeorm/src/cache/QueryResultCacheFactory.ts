import { RedisQueryResultCache } from "./RedisQueryResultCache"
import { DbQueryResultCache } from "./DbQueryResultCache"
import type { QueryResultCache } from "./QueryResultCache"
import type { DataSource } from "../data-source/DataSource"
import { TypeORMError } from "../error/TypeORMError"

/**
 * Caches query result into Redis database.
 */
export class QueryResultCacheFactory {
    // -------------------------------------------------------------------------
    // Constructor
    // -------------------------------------------------------------------------

    constructor(protected dataSource: DataSource) {}

    // -------------------------------------------------------------------------
    // Public Methods
    // -------------------------------------------------------------------------

    /**
     * Creates a new query result cache based on connection options.
     */
    create(): QueryResultCache {
        if (!this.dataSource.options.cache)
            throw new TypeORMError(
                `To use cache you need to enable it in connection options by setting cache: true or providing some caching options. Example: { host: ..., username: ..., cache: true }`,
            )

        const cache: any = this.dataSource.options.cache

        if (cache.provider && typeof cache.provider === "function") {
            return cache.provider(this.dataSource)
        }

        if (
            cache.type === "redis" ||
            cache.type === "ioredis" ||
            cache.type === "ioredis/cluster"
        ) {
            return new RedisQueryResultCache(this.dataSource, cache.type)
        } else {
            return new DbQueryResultCache(this.dataSource)
        }
    }
}
