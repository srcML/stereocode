import type { QueryResultCache } from "../cache/QueryResultCache"
import type { MixedList } from "../common/MixedList"
import type { DataSource } from "../data-source/DataSource"
import type { DatabaseType } from "../driver/types/DatabaseType"
import type { InvalidFindOptionsWhereBehavior } from "../driver/types/InvalidFindOptionsWhereBehavior"
import type { IsolationLevel } from "../driver/types/IsolationLevel"
import type { EntitySchema } from "../entity-schema/EntitySchema"
import type { Logger } from "../logger/Logger"
import type { LoggerOptions } from "../logger/LoggerOptions"
import type { NamingStrategyInterface } from "../naming-strategy/NamingStrategyInterface"

/**
 * BaseDataSourceOptions is set of DataSourceOptions shared by all database types.
 */
export interface BaseDataSourceOptions {
    /**
     * Database type. This value is required.
     */
    readonly type: DatabaseType

    /**
     * Entities to be loaded for this connection.
     * Accepts both entity classes and directories where from entities need to be loaded.
     * Directories support glob patterns.
     */
    readonly entities?: MixedList<Function | string | EntitySchema>

    /**
     * Subscribers to be loaded for this connection.
     * Accepts both subscriber classes and directories where from subscribers need to be loaded.
     * Directories support glob patterns.
     */
    readonly subscribers?: MixedList<Function | string>

    /**
     * Default isolation level for transactions. When set, all transactions started
     * without an explicit level will use this value. An explicit isolation level
     * passed to `transaction()` or `startTransaction()` overrides this default.
     * Must be a level supported by the driver.
     */
    readonly isolationLevel?: IsolationLevel

    /**
     * Migrations to be loaded for this connection.
     * Accepts both migration classes and glob patterns representing migration files.
     */
    readonly migrations?: MixedList<Function | string>

    /**
     * Migrations table name, in case of different name from "migrations".
     * Accepts single string name.
     */
    readonly migrationsTableName?: string

    /**
     * Transaction mode for migrations to run in
     */
    readonly migrationsTransactionMode?: "all" | "none" | "each"

    /**
     * Typeorm metadata table name, in case of different name from "typeorm_metadata".
     * Accepts single string name.
     */
    readonly metadataTableName?: string

    /**
     * Naming strategy to be used to name tables and columns in the database.
     */
    readonly namingStrategy?: NamingStrategyInterface

    /**
     * Logging options.
     */
    readonly logging?: LoggerOptions

    /**
     * Logger instance used to log queries and events in the ORM.
     */
    readonly logger?:
        | "advanced-console"
        | "simple-console"
        | "formatted-console"
        | "file"
        | "debug"
        | Logger

    /**
     * Maximum number of milliseconds query should be executed before logger log a warning.
     */
    readonly maxQueryExecutionTime?: number

    /**
     * Maximum number of clients the pool should contain.
     */
    readonly poolSize?: number

    /**
     * Indicates if database schema should be auto created on every application launch.
     * Be careful with this option and don't use this in production - otherwise you can lose production data.
     * This option is useful during debug and development.
     * Alternative to it, you can use CLI and run schema:sync command.
     *
     * Note that for MongoDB database it does not create schema, because MongoDB is schemaless.
     * Instead, it syncs just by creating indices.
     */
    readonly synchronize?: boolean

    /**
     * Indicates if migrations should be auto run on every application launch.
     * Alternative to it, you can use CLI and run migrations:run command.
     */
    readonly migrationsRun?: boolean

    /**
     * Drops the schema each time connection is being established.
     * Be careful with this option and don't use this in production - otherwise you'll lose all production data.
     * This option is useful during debug and development.
     */
    readonly dropSchema?: boolean

    /**
     * Prefix to use on all tables (collections) of this connection in the database.
     */
    readonly entityPrefix?: string

    /**
     * When creating new Entity instances, skip all constructors when true.
     */
    readonly entitySkipConstructor?: boolean

    /**
     * Extra connection options passed through to the underlying driver client
     * (e.g. `pg`, `mysql2`, `tedious`, `mongodb`).
     *
     * Use this for driver-native settings that are not modeled as typed
     * options on the per-driver `DataSourceOptions`. Prefer the typed
     * per-driver options when they exist; `extra` is the escape hatch for
     * anything the driver supports but TypeORM does not expose directly.
     */
    readonly extra?: any

    /**
     * Specifies how relations must be loaded - using "joins" or separate queries.
     * If you are loading too much data with nested joins it's better to load relations
     * using separate queries.
     *
     * Default strategy is "join", but this default can be changed here.
     * Also, strategy can be set per-query in FindOptions and QueryBuilder.
     */
    readonly relationLoadStrategy?: "join" | "query"

    /**
     * Optionally applied "typename" to the model.
     * If set, then each hydrated model will have this property with the target model / entity name inside.
     *
     * (works like a discriminator property).
     */
    readonly typename?: string

    /**
     * Holds reference to the baseDirectory where configuration file are expected.
     *
     * @internal
     */
    baseDirectory?: string

    /**
     * Allows to setup cache options.
     */
    readonly cache?:
        | boolean
        | {
              /**
               * Type of caching.
               *
               * - "database" means cached values will be stored in the separate table in database. This is default value.
               * - "redis" means cached values will be stored inside redis. You must provide redis connection options.
               */
              readonly type?:
                  "database" | "redis" | "ioredis" | "ioredis/cluster" // todo: add mongodb and other cache providers as well in the future

              /**
               * Factory function for custom cache providers that implement QueryResultCache.
               */
              readonly provider?: (dataSource: DataSource) => QueryResultCache

              /**
               * Configurable table name for "database" type cache.
               * Default value is "query-result-cache"
               */
              readonly tableName?: string

              /**
               * Used to provide redis connection options.
               */
              readonly options?: any

              /**
               * If set to true then queries (using find methods and QueryBuilder's methods) will always be cached.
               */
              readonly alwaysEnabled?: boolean

              /**
               * Time in milliseconds in which cache will expire.
               * This can be setup per-query.
               * Default value is 1000 which is equivalent to 1 second.
               */
              readonly duration?: number

              /**
               * Used to specify if cache errors should be ignored, and pass through the call to the Database.
               */
              readonly ignoreErrors?: boolean
          }

    /**
     * Allows automatic isolation of where clauses
     */
    readonly isolateWhereStatements?: boolean

    /**
     * Controls how null/undefined values in where criteria are handled by find
     * and write methods (update/delete/softDelete/restore). Defaults to "throw".
     */
    readonly invalidWhereValuesBehavior?: InvalidFindOptionsWhereBehavior
}
