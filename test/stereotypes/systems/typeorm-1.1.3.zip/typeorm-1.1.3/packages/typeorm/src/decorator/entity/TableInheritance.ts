import { getMetadataArgsStorage } from "../../globals"
import type { InheritanceMetadataArgs } from "../../metadata-args/InheritanceMetadataArgs"
import type { ColumnOptions } from "../options/ColumnOptions"

/**
 * Sets for entity to use table inheritance pattern.
 *
 * @param options
 * @param options.pattern
 * @param options.column
 */
export function TableInheritance(options?: {
    pattern?: "STI" /*|"CTI"*/
    column?: string | ColumnOptions
}): ClassDecorator {
    return function (target: Function) {
        getMetadataArgsStorage().inheritances.push({
            target: target,
            pattern: options?.pattern ?? "STI",
            column: options?.column
                ? typeof options.column === "string"
                    ? { name: options.column }
                    : options.column
                : undefined,
        } as InheritanceMetadataArgs)
    }
}
