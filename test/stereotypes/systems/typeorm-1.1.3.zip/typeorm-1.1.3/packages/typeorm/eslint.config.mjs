import js from "@eslint/js"
import chaiFriendly from "eslint-plugin-chai-friendly"
import { jsdoc } from "eslint-plugin-jsdoc"
import unicorn from "eslint-plugin-unicorn"
import { defineConfig, globalIgnores } from "eslint/config"
import ts from "typescript-eslint"

const __dirname = import.meta.dirname

export default defineConfig([
    globalIgnores([
        "build/**",
        "coverage/**",
        "node_modules/**",
        "src/driver/mongodb/{typings.ts,bson.typings.ts}",
        "temp/**",
    ]),

    {
        files: ["**/*.ts"],
        languageOptions: {
            parser: ts.parser,
            parserOptions: {
                tsconfigRootDir: __dirname,
                project: "tsconfig.json",
            },
        },
        plugins: {
            js,
            ts,
            unicorn,
        },
        extends: [js.configs.recommended, ...ts.configs.recommendedTypeChecked],
        rules: {
            // custom rules
            "@typescript-eslint/consistent-type-exports": "error",
            "@typescript-eslint/consistent-type-imports": "error",
            "@typescript-eslint/prefer-nullish-coalescing": "error",
            "@typescript-eslint/prefer-optional-chain": "error",
            "@typescript-eslint/prefer-string-starts-ends-with": "error",

            "unicorn/prefer-string-replace-all": "error",
            "unicorn/prefer-string-slice": "error",

            // exceptions from typescript-eslint/recommended
            "@typescript-eslint/ban-ts-comment": "warn",
            "@typescript-eslint/no-empty-object-type": "warn",
            "@typescript-eslint/no-explicit-any": "warn",
            "@typescript-eslint/no-require-imports": "warn",
            "@typescript-eslint/no-this-alias": "warn",
            "@typescript-eslint/no-unnecessary-type-constraint": "warn",
            "@typescript-eslint/no-unsafe-declaration-merging": "warn",
            "@typescript-eslint/no-unsafe-function-type": "warn",
            "@typescript-eslint/no-unused-vars": [
                "warn",
                {
                    argsIgnorePattern: "^_",
                    destructuredArrayIgnorePattern: "^_",
                },
            ],
            "@typescript-eslint/no-wrapper-object-types": "off",
            "prefer-const": ["error", { destructuring: "all" }],

            // exceptions from typescript-eslint/recommended-type-checked
            "@typescript-eslint/no-base-to-string": "off",
            "@typescript-eslint/no-misused-promises": [
                "error",
                {
                    checksConditionals: false,
                    checksVoidReturn: false,
                },
            ],
            "@typescript-eslint/no-redundant-type-constituents": "warn",
            "@typescript-eslint/no-unnecessary-type-assertion": "off",
            "@typescript-eslint/no-unsafe-argument": "off",
            "@typescript-eslint/no-unsafe-assignment": "off",
            "@typescript-eslint/no-unsafe-call": "off",
            "@typescript-eslint/no-unsafe-member-access": "off",
            "@typescript-eslint/no-unsafe-return": "off",
            "@typescript-eslint/prefer-promise-reject-errors": "off",
            "@typescript-eslint/require-await": "warn",
            "@typescript-eslint/restrict-plus-operands": "warn",
            "@typescript-eslint/restrict-template-expressions": "warn",
            "@typescript-eslint/unbound-method": [
                "warn",
                { ignoreStatic: true },
            ],

            // exceptions for eslint/recommended
            "no-async-promise-executor": "warn",
            "no-useless-assignment": "warn",
            "no-control-regex": "warn",
            "no-empty": "warn",
            "no-loss-of-precision": "warn",
            "no-prototype-builtins": "warn",
            "no-regex-spaces": "warn",
            "no-return-assign": ["error", "always"],
            "preserve-caught-error": "warn",
        },
    },

    jsdoc({
        files: ["src/**/*.ts"],
        config: "flat/recommended-typescript", // change to 'flat/recommended-typescript-error' once warnings are fixed
        // Temporarily enable individual rules when they are fixed, until all current warnings are gone,
        // and then remove manual config in favor of `config: "flat/recommended-typescript-error"`
        rules: {
            "jsdoc/valid-types": "error",
            "jsdoc/tag-lines": [
                "error",
                "any",
                {
                    startLines: 1,
                    tags: { example: { lines: "always", count: 1 } },
                },
            ],
        },
    }),

    {
        files: ["test/**/*.ts"],
        ...chaiFriendly.configs.recommendedFlat,
    },
])
