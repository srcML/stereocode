import path from "node:path"
import type { ASTNode, API, FileInfo } from "jscodeshift"
import { addTodoComment, hasTodoComment } from "../todo"
import { stats } from "../stats"

export const name = path.basename(__filename, path.extname(__filename))
export const description =
    "flag removed `loadedTables` and `loadedViews` for manual migration to `getTables()` / `getViews()`"
export const manual = true

interface TraversalNode {
    parent?: TraversalNode & {
        node: ASTNode & {
            type: string
            comments?: { value: string }[]
        }
    }
}

export const queryRunnerLoadedTablesViews = (file: FileInfo, api: API) => {
    const j = api.jscodeshift
    const root = j(file.source)
    let hasChanges = false
    let hasTodos = false

    const removedProps = new Set(["loadedTables", "loadedViews"])

    root.find(j.MemberExpression).forEach((path) => {
        if (path.node.property.type !== "Identifier") return
        if (!removedProps.has(path.node.property.name)) return

        const propName = path.node.property.name

        let current: TraversalNode = path
        while (current.parent && current.parent.node.type !== "Program") {
            if (
                current.parent.node.type === "ExpressionStatement" ||
                current.parent.node.type === "VariableDeclaration" ||
                current.parent.node.type === "ReturnStatement"
            ) {
                const stmt = current.parent.node
                const message = `\`${propName}\` was removed — use \`getTables()\` / \`getViews()\` instead`
                if (!hasTodoComment(stmt, message)) {
                    addTodoComment(stmt, message, j)
                    hasTodos = true
                }
                hasChanges = true
                break
            }
            current = current.parent
        }
    })

    if (hasTodos) stats.count.todo(api, name, file)

    return hasChanges ? root.toSource() : undefined
}

export const fn = queryRunnerLoadedTablesViews
export default fn
